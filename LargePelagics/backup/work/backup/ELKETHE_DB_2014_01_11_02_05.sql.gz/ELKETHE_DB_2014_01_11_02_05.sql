-- Status:19:1414:MP_0:ELKETHE_DB:php:1.24.4::5.5.34-0ubuntu0.12.04.1:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|ALBmeasure|0|32768||InnoDB
-- TABLE|BFTmeasure|0|16384||InnoDB
-- TABLE|OTHERmeasure|0|32768||InnoDB
-- TABLE|RVTmeasure|0|32768||InnoDB
-- TABLE|SWOmeasure|0|16384||InnoDB
-- TABLE|dynamic_vessel|0|32768||InnoDB
-- TABLE|dynamic_vessel_ID|0|32768||InnoDB
-- TABLE|expedition|0|32768||InnoDB
-- TABLE|expedition_size|0|32768||InnoDB
-- TABLE|gears|11|16384||InnoDB
-- TABLE|ports|9|16384||InnoDB
-- TABLE|production|445|65536||InnoDB
-- TABLE|production_ID|445|49152||InnoDB
-- TABLE|species|52|16384||InnoDB
-- TABLE|species_measurements|0|49152||InnoDB
-- TABLE|users|6|32768||InnoDB
-- TABLE|users_action_history|2|262144||InnoDB
-- TABLE|vessel|444|81920||InnoDB
-- TABLE|vessel_expeditions|0|49152||InnoDB
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2014-01-11 02:05

--
-- Create Table `ALBmeasure`
--

DROP TABLE IF EXISTS `ALBmeasure`;
CREATE TABLE `ALBmeasure` (
  `ALB_measure_ID` int(11) NOT NULL,
  `fl` double DEFAULT NULL,
  `gg` double DEFAULT NULL,
  `dw` double DEFAULT NULL,
  `rw` double DEFAULT NULL,
  `sex` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `matur_stage` int(11) DEFAULT NULL,
  `gon_wei` double DEFAULT NULL,
  `lIfe_status` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `bait_type` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `commercial` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`ALB_measure_ID`),
  UNIQUE KEY `ALB_measure_ID_UNIQUE` (`ALB_measure_ID`),
  CONSTRAINT `measure_ID` FOREIGN KEY (`ALB_measure_ID`) REFERENCES `species_measurements` (`measure_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=greek;

--
-- Data for Table `ALBmeasure`
--

/*!40000 ALTER TABLE `ALBmeasure` DISABLE KEYS */;
/*!40000 ALTER TABLE `ALBmeasure` ENABLE KEYS */;


--
-- Create Table `BFTmeasure`
--

DROP TABLE IF EXISTS `BFTmeasure`;
CREATE TABLE `BFTmeasure` (
  `BFT_measure_ID` int(11) NOT NULL,
  `fl` double DEFAULT NULL,
  `gg` double DEFAULT NULL,
  `dw` double DEFAULT NULL,
  `rw` double DEFAULT NULL,
  `sex` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `pfl` double DEFAULT NULL,
  `matur_stage` int(11) DEFAULT NULL,
  `gon_wei` double DEFAULT NULL,
  `life_status` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `bait_type` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `commercial` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`BFT_measure_ID`),
  CONSTRAINT `BFT_measure_ID` FOREIGN KEY (`BFT_measure_ID`) REFERENCES `species_measurements` (`measure_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=greek;

--
-- Data for Table `BFTmeasure`
--

/*!40000 ALTER TABLE `BFTmeasure` DISABLE KEYS */;
/*!40000 ALTER TABLE `BFTmeasure` ENABLE KEYS */;


--
-- Create Table `OTHERmeasure`
--

DROP TABLE IF EXISTS `OTHERmeasure`;
CREATE TABLE `OTHERmeasure` (
  `OTHER_measure_ID` int(11) NOT NULL,
  `species_name` varchar(45) DEFAULT 'UNKNOWN',
  `common_name` varchar(45) DEFAULT 'UNKNOWN',
  `fl` double DEFAULT NULL,
  `tl` double DEFAULT NULL,
  `gg` double DEFAULT NULL,
  `dw` double DEFAULT NULL,
  `rw` double DEFAULT NULL,
  `sex` varchar(45) DEFAULT 'UNKNOWN',
  `life_status` varchar(45) DEFAULT 'UNKNOWN',
  `bait_type` varchar(45) DEFAULT 'UNKNOWN',
  `commercial` varchar(45) DEFAULT 'UNKNOWN',
  PRIMARY KEY (`OTHER_measure_ID`),
  UNIQUE KEY `OTHER_measure_ID_UNIQUE` (`OTHER_measure_ID`),
  CONSTRAINT `OTHER_measure_ID` FOREIGN KEY (`OTHER_measure_ID`) REFERENCES `species_measurements` (`measure_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=greek;

--
-- Data for Table `OTHERmeasure`
--

/*!40000 ALTER TABLE `OTHERmeasure` DISABLE KEYS */;
/*!40000 ALTER TABLE `OTHERmeasure` ENABLE KEYS */;


--
-- Create Table `RVTmeasure`
--

DROP TABLE IF EXISTS `RVTmeasure`;
CREATE TABLE `RVTmeasure` (
  `RVT_measure_ID` int(11) NOT NULL,
  `fl` double DEFAULT NULL,
  `tl` double DEFAULT NULL,
  `pffl` double DEFAULT NULL,
  `gg` double DEFAULT NULL,
  `dw` double DEFAULT NULL,
  `rw` double DEFAULT NULL,
  `sex` varchar(45) DEFAULT 'UNKNOWN',
  `life_status` varchar(45) DEFAULT 'UNKNOWN',
  `bait_type` varchar(45) DEFAULT 'UNKNOWN',
  `commercial` varchar(45) DEFAULT 'UNKNOWN',
  PRIMARY KEY (`RVT_measure_ID`),
  UNIQUE KEY `RVT_measure_ID_UNIQUE` (`RVT_measure_ID`),
  CONSTRAINT `RVT_measure_ID` FOREIGN KEY (`RVT_measure_ID`) REFERENCES `species_measurements` (`measure_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=greek;

--
-- Data for Table `RVTmeasure`
--

/*!40000 ALTER TABLE `RVTmeasure` DISABLE KEYS */;
/*!40000 ALTER TABLE `RVTmeasure` ENABLE KEYS */;


--
-- Create Table `SWOmeasure`
--

DROP TABLE IF EXISTS `SWOmeasure`;
CREATE TABLE `SWOmeasure` (
  `SWO_measure_ID` int(11) NOT NULL,
  `ljfl` double DEFAULT NULL,
  `gg` double DEFAULT NULL,
  `sex` varchar(45) DEFAULT 'UNKNOWN',
  `rw` double DEFAULT NULL,
  `dw` double DEFAULT NULL,
  `pfl` double DEFAULT NULL,
  `head_length` double DEFAULT NULL,
  `matur_stage` int(11) DEFAULT NULL,
  `gon_wei` double DEFAULT NULL,
  `parasites` varchar(45) DEFAULT 'UNKNOWN',
  `life_status` varchar(45) DEFAULT 'UNKNOWN',
  `bait_type` varchar(45) DEFAULT 'UNKNOWN',
  `commercial` varchar(45) DEFAULT 'UNKNOWN',
  PRIMARY KEY (`SWO_measure_ID`),
  CONSTRAINT `SWO_measure_ID` FOREIGN KEY (`SWO_measure_ID`) REFERENCES `species_measurements` (`measure_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=greek;

--
-- Data for Table `SWOmeasure`
--

/*!40000 ALTER TABLE `SWOmeasure` DISABLE KEYS */;
/*!40000 ALTER TABLE `SWOmeasure` ENABLE KEYS */;


--
-- Create Table `dynamic_vessel`
--

DROP TABLE IF EXISTS `dynamic_vessel`;
CREATE TABLE `dynamic_vessel` (
  `vessel_production_ID` int(11) NOT NULL,
  `Winch_type` varchar(45) DEFAULT NULL,
  `year` int(11) NOT NULL,
  `float_distance` varchar(45) DEFAULT NULL,
  `branch_line_distance` varchar(45) DEFAULT NULL,
  `ml_diameter` int(10) unsigned zerofill DEFAULT NULL,
  `bl_diameter` int(10) unsigned zerofill DEFAULT NULL,
  `bl_legnth` int(10) unsigned zerofill DEFAULT NULL,
  `float_length` int(10) unsigned zerofill DEFAULT NULL,
  `hooks_set` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `hooks_no` int(11) unsigned zerofill DEFAULT NULL,
  `extra_comments` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`vessel_production_ID`),
  UNIQUE KEY `vessel_production_ID_UNIQUE` (`vessel_production_ID`),
  CONSTRAINT `dvessel_ID` FOREIGN KEY (`vessel_production_ID`) REFERENCES `dynamic_vessel_ID` (`dynamic_vessel_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=greek;

--
-- Data for Table `dynamic_vessel`
--

/*!40000 ALTER TABLE `dynamic_vessel` DISABLE KEYS */;
/*!40000 ALTER TABLE `dynamic_vessel` ENABLE KEYS */;


--
-- Create Table `dynamic_vessel_ID`
--

DROP TABLE IF EXISTS `dynamic_vessel_ID`;
CREATE TABLE `dynamic_vessel_ID` (
  `AMAS` varchar(45) CHARACTER SET greek NOT NULL,
  `dynamic_vessel_ID` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`dynamic_vessel_ID`),
  KEY `AMAS_idx` (`AMAS`),
  CONSTRAINT `V_AMAS` FOREIGN KEY (`AMAS`) REFERENCES `vessel` (`AMAS`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Data for Table `dynamic_vessel_ID`
--

/*!40000 ALTER TABLE `dynamic_vessel_ID` DISABLE KEYS */;
/*!40000 ALTER TABLE `dynamic_vessel_ID` ENABLE KEYS */;


--
-- Create Table `expedition`
--

DROP TABLE IF EXISTS `expedition`;
CREATE TABLE `expedition` (
  `expedition_ID` int(11) NOT NULL AUTO_INCREMENT,
  `deployDate` date DEFAULT NULL,
  `returnDate` date DEFAULT NULL,
  `Hooks_day` varchar(45) DEFAULT 'UNKNOWN',
  `FishingDays` int(11) DEFAULT NULL,
  `Effort` int(11) DEFAULT NULL,
  `Gear` varchar(45) DEFAULT 'UNKNOWN',
  `Detail_Area` varchar(150) DEFAULT 'UNKNOWN',
  `StartSettingTime` time DEFAULT NULL,
  `StartLat` varchar(45) DEFAULT 'UNKNOWN',
  `StartLON` varchar(45) DEFAULT NULL,
  `EndSetTime` time DEFAULT NULL,
  `EndLAT` varchar(45) DEFAULT 'UNKNOWN',
  `EndLON` varchar(45) DEFAULT 'UNKNOWN',
  `StartHaulTime` time DEFAULT NULL,
  `StartLATHaul` varchar(45) DEFAULT 'UNKNOWN',
  `StartLONHaul` varchar(45) DEFAULT 'UNKNOWN',
  `EndHaulTime` time DEFAULT NULL,
  `EndLATHaul` varchar(45) DEFAULT 'UNKNOWN',
  `EndLONHaul` varchar(45) DEFAULT 'UNKNOWN',
  `Lightsticks` tinyint(1) DEFAULT NULL,
  `InfoOrigin` varchar(45) DEFAULT 'UNKNOWN',
  `Comments` varchar(200) DEFAULT 'UNKNOWN',
  PRIMARY KEY (`expedition_ID`),
  UNIQUE KEY `expedition_ID` (`expedition_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=greek;

--
-- Data for Table `expedition`
--

/*!40000 ALTER TABLE `expedition` DISABLE KEYS */;
/*!40000 ALTER TABLE `expedition` ENABLE KEYS */;


--
-- Create Table `expedition_size`
--

DROP TABLE IF EXISTS `expedition_size`;
CREATE TABLE `expedition_size` (
  `weight` double DEFAULT NULL,
  `num` int(11) DEFAULT NULL,
  `species` varchar(45) NOT NULL,
  `size_expedition_ID` int(11) NOT NULL,
  PRIMARY KEY (`species`,`size_expedition_ID`),
  KEY `expedition_ID_idx` (`size_expedition_ID`),
  CONSTRAINT `size_expedition_ID` FOREIGN KEY (`size_expedition_ID`) REFERENCES `vessel_expeditions` (`expedition_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=greek;

--
-- Data for Table `expedition_size`
--

/*!40000 ALTER TABLE `expedition_size` DISABLE KEYS */;
/*!40000 ALTER TABLE `expedition_size` ENABLE KEYS */;


--
-- Create Table `gears`
--

DROP TABLE IF EXISTS `gears`;
CREATE TABLE `gears` (
  `name` varchar(45) NOT NULL,
  `code` varchar(45) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `gears`
--

/*!40000 ALTER TABLE `gears` DISABLE KEYS */;
INSERT INTO `gears` (`name`,`code`) VALUES ('Albacore longline','LAL');
INSERT INTO `gears` (`name`,`code`) VALUES ('American longline','LLA');
INSERT INTO `gears` (`name`,`code`) VALUES ('Bottom longline','BLL');
INSERT INTO `gears` (`name`,`code`) VALUES ('Bottom trawl','BT');
INSERT INTO `gears` (`name`,`code`) VALUES ('Classic longline','LLC');
INSERT INTO `gears` (`name`,`code`) VALUES ('Diving','D');
INSERT INTO `gears` (`name`,`code`) VALUES ('Handline','HL');
INSERT INTO `gears` (`name`,`code`) VALUES ('Nets','N');
INSERT INTO `gears` (`name`,`code`) VALUES ('Traps','TRP');
INSERT INTO `gears` (`name`,`code`) VALUES ('Troll-line','TL');
INSERT INTO `gears` (`name`,`code`) VALUES ('Unknown','UN');
/*!40000 ALTER TABLE `gears` ENABLE KEYS */;


--
-- Create Table `ports`
--

DROP TABLE IF EXISTS `ports`;
CREATE TABLE `ports` (
  `name` varchar(45) NOT NULL,
  `code` varchar(45) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `ports`
--

/*!40000 ALTER TABLE `ports` DISABLE KEYS */;
INSERT INTO `ports` (`name`,`code`) VALUES ('Αλόννησος','ALO');
INSERT INTO `ports` (`name`,`code`) VALUES ('Κρήτη','CRE');
INSERT INTO `ports` (`name`,`code`) VALUES ('Κυκλάδες','CYC');
INSERT INTO `ports` (`name`,`code`) VALUES ('Χαλκιδική','HAL');
INSERT INTO `ports` (`name`,`code`) VALUES ('Χανιά','HAN');
INSERT INTO `ports` (`name`,`code`) VALUES ('Iόνιο','ION');
INSERT INTO `ports` (`name`,`code`) VALUES ('Κάλυμνος','KAL');
INSERT INTO `ports` (`name`,`code`) VALUES ('Λοιπά','OTH');
INSERT INTO `ports` (`name`,`code`) VALUES ('Πάτρα','PAT');
/*!40000 ALTER TABLE `ports` ENABLE KEYS */;


--
-- Create Table `production`
--

DROP TABLE IF EXISTS `production`;
CREATE TABLE `production` (
  `production_ID` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `SWOproduction` int(11) unsigned zerofill DEFAULT NULL,
  `ALBproduction` int(11) unsigned zerofill DEFAULT NULL,
  `BFTproduction` int(11) unsigned zerofill DEFAULT NULL,
  `RVTproduction` int(11) unsigned zerofill DEFAULT NULL,
  `fishing_days` int(11) unsigned zerofill DEFAULT NULL,
  `wtc` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `bait` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`production_ID`),
  UNIQUE KEY `production_ID_UNIQUE` (`production_ID`),
  CONSTRAINT `production_ID` FOREIGN KEY (`production_ID`) REFERENCES `production_ID` (`production_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=greek;

--
-- Data for Table `production`
--

/*!40000 ALTER TABLE `production` DISABLE KEYS */;
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('1','1991','00000014600',NULL,NULL,NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('2','1991','00000007800',NULL,NULL,NULL,NULL,'2',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('3','2001','00000005557',NULL,'00000000750',NULL,NULL,'3','Θραψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('4','2003',NULL,NULL,NULL,NULL,NULL,'2','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('5','1991','00000035000',NULL,NULL,NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('6','1994','00000012500',NULL,'00000012500',NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('7','1995',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('8','1995',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('9','1989',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('10','1989',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('11','1989',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('12','1989',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('13','1989',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('14','1989',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('15','1989',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('16','1989',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('17','1989',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('18','1989',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('19','1989',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('20','1989',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('21','1989',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('22','1989',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('23','1989',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('24','1989',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('25','1989',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('26','1989',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('27','1993','00000000325',NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('28','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('29','1992',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('30','2000',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('31','1994',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('32','1995',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('33','1999','00000004200',NULL,'00000001200',NULL,NULL,'2','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('34','2000','00000008000',NULL,'00000004050',NULL,NULL,'3',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('35','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('36','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('37','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('38','1995',NULL,NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('39','1995',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('40','2003',NULL,NULL,NULL,NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('41','2006',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('42','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('43','1995',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('44','1987',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('45','2002','00000002000',NULL,'00000000000',NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('46','2003',NULL,NULL,NULL,NULL,NULL,'2',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('47','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('48','1995',NULL,NULL,NULL,NULL,NULL,NULL,'Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('49','2004',NULL,NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('50','1995',NULL,NULL,NULL,NULL,NULL,'1','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('51','1995',NULL,NULL,NULL,NULL,NULL,'2','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('52','1995',NULL,NULL,NULL,NULL,NULL,'4','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('53','2000',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('54','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('55','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('56','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('57','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('58','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('59','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('60','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('61','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('62','1995',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('63','1987',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('64','1987',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('65','1994','00000008600',NULL,NULL,NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('66','2001',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('67','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('68','1995',NULL,NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('69','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('70','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('71','1999','00000003500',NULL,'00000001250',NULL,NULL,'4','Θραψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('72','1995',NULL,NULL,NULL,NULL,NULL,'3',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('73','1987',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('74','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('75','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('76','1995',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('77','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('78','2003',NULL,NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('79','2001',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('80','1995',NULL,NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('81','1998','00000004600',NULL,'00000000650',NULL,NULL,'2',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('82','1999',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('83','1998',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('84','1999',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('85','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('86','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('87','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('88','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('89','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('90','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('91','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('92','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('93','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('94','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('95','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('96','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('97','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('98','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('99','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('100','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('101','2005',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('102','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('103','1991','00000001000',NULL,NULL,NULL,NULL,'2',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('104','1998',NULL,NULL,NULL,NULL,NULL,NULL,'Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('105','1999',NULL,NULL,NULL,NULL,NULL,NULL,'Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('106','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('107','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('108','2011','00000017270',NULL,'00000000400',NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('109','1991','00000020785',NULL,NULL,NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('110','1999',NULL,NULL,NULL,NULL,NULL,'2','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('111','2003',NULL,NULL,NULL,NULL,NULL,'3','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('112','1998',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('113','1999',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('114','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('115','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('116','1998',NULL,NULL,NULL,NULL,NULL,'3','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('117','1999',NULL,NULL,NULL,NULL,NULL,'3','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('118','2001',NULL,NULL,NULL,NULL,NULL,'3',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('119','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('120','2009',NULL,NULL,NULL,NULL,NULL,NULL,'skoubri');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('121','1993','00000001500',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('122','2005',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('123','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('124','2006',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('125','1999',NULL,NULL,NULL,NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('126','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('127','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('128','2005',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί, Θράψαλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('129','2005',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('130','2002','00000017487',NULL,'00000004400',NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('131','2003','00000000501',NULL,'00000000000',NULL,NULL,'2',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('132','1995',NULL,NULL,NULL,NULL,NULL,NULL,'Θραψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('133','1991','00000022490',NULL,NULL,NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('134','1998',NULL,NULL,NULL,NULL,NULL,'2','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('135','1999',NULL,NULL,NULL,NULL,NULL,'2','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('136','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('137','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('138','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('139','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('140','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('141','1998',NULL,NULL,NULL,NULL,NULL,'3','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('142','1999',NULL,NULL,NULL,NULL,NULL,'1','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('143','1998',NULL,NULL,NULL,NULL,NULL,'3','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('144','2003','00000001150',NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('145','2006',NULL,NULL,NULL,NULL,NULL,NULL,'θράψαλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('146','1994','00000001300',NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('147','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('148','1998',NULL,NULL,NULL,NULL,NULL,NULL,'Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('149','1998',NULL,NULL,NULL,NULL,NULL,'3','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('150','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('151','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('152','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('153','1998',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('154','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('155','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('156','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('157','1998',NULL,NULL,NULL,NULL,NULL,'1','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('158','1991','00000013060',NULL,NULL,NULL,NULL,'3',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('159','1999',NULL,NULL,NULL,NULL,NULL,'3','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('160','2003','00000004858',NULL,'00000000000',NULL,NULL,'2','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('161','1987',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('162','1991','00000015295',NULL,NULL,NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('163','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('164','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('165','2005',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('166','1991','00000007250',NULL,NULL,NULL,NULL,'3','Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('167','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('168','2006',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('169','1998',NULL,NULL,NULL,NULL,NULL,'3','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('170','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('171','2005',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('172','1987',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('173','1998',NULL,NULL,NULL,NULL,NULL,'3','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('174','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('175','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('176','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('177','2001',NULL,NULL,NULL,NULL,NULL,'4','Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('178','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('179','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('180','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('181','2005',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('182','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('183','2006',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('184','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('185','1995',NULL,NULL,NULL,NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('186','1999','00000012500',NULL,'00000001200',NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('187','1987',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('188','2001',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('189','1991','00000004670',NULL,NULL,NULL,NULL,'3',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('190','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('191','1991','00000021650',NULL,NULL,NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('192','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('193','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('194','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('195','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('196','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('197','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('198','1993','00000000125',NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('199','1998',NULL,NULL,NULL,NULL,NULL,'1','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('200','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('201','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('202','2006',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('203','1998',NULL,NULL,NULL,NULL,NULL,'2',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('204','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('205','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('206','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('207','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('208','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('209','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('210','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('211','1998',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('212','2005',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('213','2009',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('214','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('215','1999',NULL,NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('216','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('217','1992',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('218','1992',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('219','1993','00000005845',NULL,NULL,NULL,NULL,'2',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('220','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('221','1994','00000009200',NULL,'00000002150',NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('222','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('223','1999',NULL,NULL,NULL,NULL,NULL,'4','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('224','2001',NULL,NULL,NULL,NULL,NULL,'4','Θραψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('225','1995',NULL,NULL,NULL,NULL,NULL,'4','Θραψαλλο-λαμπάκια');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('226','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('227','1998',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('228','1995',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('229','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('230','1998',NULL,NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('231','1995',NULL,NULL,NULL,NULL,NULL,'4','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('232','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('233','1992',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('234','1994',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('235','1999','00000006200',NULL,'00000002100',NULL,NULL,'3','Θραψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('236','2003','00000006900',NULL,'00000000660',NULL,NULL,'4','Θραψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('237','1999',NULL,NULL,NULL,NULL,NULL,'4','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('238','2003','00000012101',NULL,'00000002081',NULL,NULL,'3','Θραψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('239','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('240','1994','00000023700',NULL,NULL,NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('241','2004','00000001500',NULL,'00000000450',NULL,NULL,'2','σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('242','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('243','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('244','1993','00000003500',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('245','2002','00000003500',NULL,'00000000080',NULL,NULL,'3',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('246','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('247','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('248','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('249','1991','00000003100',NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('250','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('251','1986',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('252','1995',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('253','2001',NULL,NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('254','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('255','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('256','2000',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('257','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('258','1995',NULL,NULL,NULL,NULL,NULL,'4','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('259','1995',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('260','1995',NULL,NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('261','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('262','1999','00000014000',NULL,'00000007100',NULL,NULL,'3','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('263','2006',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('264','1991','00000011000',NULL,NULL,NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('265','1987',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('266','2005',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('267','1987',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('268','1987',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('269','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('270','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('271','2009',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί+Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('272','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('273','1998',NULL,NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('274','2008',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('275','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('276','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('277','1991','00000001800',NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('278','1998',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('279','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('280','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('281','1995',NULL,NULL,NULL,NULL,NULL,'4','Θραψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('282','2005',NULL,NULL,NULL,NULL,NULL,NULL,'Φρύσσα, Κολιός');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('283','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('284','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('285','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('286','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('287','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('288','2006',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('289','2007','00000017500',NULL,'00000000540',NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('290','1995',NULL,NULL,NULL,NULL,NULL,'3',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('291','1999',NULL,NULL,NULL,NULL,NULL,'3',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('292','2006',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('293','2001',NULL,NULL,NULL,NULL,NULL,'3',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('294','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('295','1995',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('296','1998',NULL,NULL,NULL,NULL,NULL,'2','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('297','2000','00000001730',NULL,'00000000010',NULL,NULL,'2','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('298','2004','00000019584',NULL,'00000002432',NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('299','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('300','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('301','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('302','1993','00000002500',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('303','2005',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('304','2005',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('305','2006',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('306','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('307','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('308','1993','00000000190',NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('309','1999',NULL,NULL,NULL,NULL,NULL,'1','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('310','2001','00000015000',NULL,NULL,NULL,NULL,'1','Θραψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('311','1995',NULL,NULL,NULL,NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('312','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('313','1991','00000008030',NULL,NULL,NULL,NULL,'2',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('314','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('315','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('316','1995',NULL,NULL,NULL,NULL,NULL,'3','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('317','1998',NULL,NULL,NULL,NULL,NULL,'3','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('318','1999',NULL,NULL,NULL,NULL,NULL,'3','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('319','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('320','1987',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('321','1999',NULL,NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('322','1987',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('323','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('324','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('325','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('326','2003','00000003860',NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('327','1995',NULL,NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('328','2001',NULL,NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('329','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('330','2006',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('331','1999','00000013200',NULL,'00000001250',NULL,NULL,'4','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('332','1999','00000012500',NULL,'00000001150',NULL,NULL,'4','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('333','2002','00000004400',NULL,'00000000270',NULL,NULL,'4','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('334','2003','00000005180',NULL,'00000000000',NULL,NULL,'2','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('335','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('336','2000',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('337','1999','00000005500',NULL,'00000003700',NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('338','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('339','1992',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('340','1998',NULL,NULL,NULL,NULL,NULL,'3','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('341','1995',NULL,NULL,NULL,NULL,NULL,'4','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('342','1992',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('343','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('344','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('345','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('346','1987',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('347','1994',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('348','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('349','1994',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('350','1994',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('351','1993','00000002395',NULL,NULL,NULL,NULL,'2',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('352','1993','00000000250',NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('353','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('354','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('355','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('356','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('357','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('358','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('359','1995',NULL,NULL,NULL,NULL,NULL,'1','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('360','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('361','2001','00000002630',NULL,'00000000000',NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('362','1995',NULL,NULL,NULL,NULL,NULL,'4','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('363','2000','00000002600',NULL,'00000000450',NULL,NULL,'2','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('364','1998',NULL,NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('365','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('366','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('367','2006',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('368','2001',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('369','1987',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('370','1995',NULL,NULL,NULL,NULL,NULL,'1','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('371','2002',NULL,NULL,NULL,NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('372','1987',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('373','1994','00000007000',NULL,NULL,NULL,NULL,'2',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('374','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('375','2001',NULL,NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('376','1995',NULL,NULL,NULL,NULL,NULL,'4','Θραψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('377','2003','00000016800',NULL,'00000004050',NULL,NULL,'4','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('378','2006',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('379','1987',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('380','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('381','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('382','2001','00000009200',NULL,'00000000503',NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('383','2003','00000010359',NULL,'00000002880',NULL,NULL,'3',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('384','1995',NULL,NULL,NULL,NULL,NULL,'4','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('385','1991','00000023740',NULL,NULL,NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('386','2003','00000005700',NULL,'00000004500',NULL,NULL,'3','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('387','1999','00000011500',NULL,'00000001750',NULL,NULL,'4','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('388','1991','00000005050',NULL,NULL,NULL,NULL,'2',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('389','1991','00000019000',NULL,NULL,NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('390','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('391','2001',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('392','2003','00000021500',NULL,'00000002650',NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('393','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('394','2001',NULL,NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('395','1991','00000000500',NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('396','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('397','2006',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('398','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('399','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('400','2002','00000002000',NULL,'00000000000',NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('401','2003',NULL,NULL,NULL,NULL,NULL,'2',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('402','1994','00000014000',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('403','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('404','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('405','1998',NULL,NULL,NULL,NULL,NULL,'3','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('406','2001',NULL,NULL,NULL,NULL,NULL,'3',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('407','1999',NULL,NULL,NULL,NULL,NULL,'2',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('408','2003',NULL,NULL,NULL,NULL,NULL,'2',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('409','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('410','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('411','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('412','2004',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('413','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('414','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('415','1992',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('416','2006',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('417','1998',NULL,NULL,NULL,NULL,NULL,'2','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('418','1995',NULL,NULL,NULL,NULL,NULL,NULL,'Θραψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('419','1995',NULL,NULL,NULL,NULL,NULL,'4','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('420','2003','00000004400',NULL,'00000000010',NULL,NULL,'2','Θράψαλλο-σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('421','1994','00000015000',NULL,NULL,NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('422','1992',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('423','1991','00000003960',NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('424','1998',NULL,NULL,NULL,NULL,NULL,'3','Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('425','2004',NULL,NULL,NULL,NULL,NULL,'3','Θράψαλο, Σκουμπρί');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('426','2005',NULL,NULL,NULL,NULL,NULL,NULL,'Σκουμπρί και Θράψαλλο');
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('427','1991','00000001750',NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('428','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('429','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('430','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('431','1993','00000000700',NULL,NULL,NULL,NULL,'1',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('432','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('433','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('434','1992',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('435','1998',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('436','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('437','1998',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('438','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('439','1991',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('440','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('441','1994',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('442','1991','00000009340',NULL,NULL,NULL,NULL,'4',NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('443','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('444','2003',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `production` (`production_ID`,`year`,`SWOproduction`,`ALBproduction`,`BFTproduction`,`RVTproduction`,`fishing_days`,`wtc`,`bait`) VALUES ('445','0','00000000000','00000000000','00000000000','00000000000','00000000000','\r\n  ','');
/*!40000 ALTER TABLE `production` ENABLE KEYS */;


--
-- Create Table `production_ID`
--

DROP TABLE IF EXISTS `production_ID`;
CREATE TABLE `production_ID` (
  `production_ID` int(11) NOT NULL AUTO_INCREMENT,
  `AMAS` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`production_ID`),
  UNIQUE KEY `production_ID_UNIQUE` (`production_ID`),
  KEY `AMAS_idx` (`AMAS`),
  CONSTRAINT `AMAS` FOREIGN KEY (`AMAS`) REFERENCES `vessel` (`AMAS`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=446 DEFAULT CHARSET=greek;

--
-- Data for Table `production_ID`
--

/*!40000 ALTER TABLE `production_ID` DISABLE KEYS */;
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('1',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('2',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('3',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('4',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('5',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('6',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('7',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('8',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('9',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('10',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('11',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('12',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('13',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('14',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('15',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('16',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('17',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('18',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('19',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('20',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('21',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('22',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('23',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('24',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('25',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('26',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('27',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('28',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('29',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('30',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('31',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('32',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('33',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('34',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('35',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('36',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('37',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('38',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('39',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('40',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('41',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('42',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('43',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('44',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('45',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('46',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('47',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('48',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('49',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('50',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('51',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('52',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('53',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('54',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('55',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('56',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('57',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('58',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('59',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('60',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('61',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('62',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('63',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('64',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('65',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('66',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('67',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('68',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('69',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('70',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('71',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('72',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('73',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('74',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('75',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('76',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('77',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('78',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('79',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('80',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('81',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('82',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('83',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('84',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('85',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('86',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('87',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('88',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('89',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('90',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('91',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('92',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('93',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('94',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('95',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('96',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('97',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('98',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('99',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('100',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('101',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('102',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('103',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('104',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('105',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('106',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('107',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('108',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('109',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('110',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('111',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('112',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('113',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('114',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('115',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('116',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('117',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('118',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('119',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('120',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('121',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('122',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('123',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('124',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('125',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('126',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('127',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('128',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('129',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('130',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('131',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('132',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('133',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('134',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('135',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('136',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('137',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('138',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('139',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('140',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('141',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('142',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('143',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('144',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('145',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('146',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('147',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('148',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('149',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('150',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('151',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('152',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('153',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('154',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('155',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('156',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('157',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('158',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('159',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('160',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('161',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('162',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('163',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('164',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('165',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('166',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('167',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('168',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('169',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('170',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('171',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('172',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('173',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('174',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('175',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('176',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('177',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('178',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('179',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('180',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('181',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('182',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('183',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('184',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('185',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('186',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('187',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('188',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('189',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('190',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('191',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('192',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('193',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('194',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('195',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('196',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('197',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('198',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('199',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('200',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('201',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('202',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('203',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('204',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('205',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('206',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('207',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('208',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('209',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('210',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('211',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('212',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('213',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('214',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('215',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('216',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('217',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('218',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('219',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('220',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('221',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('222',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('223',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('224',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('225',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('226',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('227',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('228',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('229',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('230',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('231',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('232',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('233',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('234',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('235',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('236',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('237',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('238',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('239',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('240',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('241',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('242',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('243',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('244',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('245',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('246',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('247',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('248',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('249',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('250',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('251',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('252',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('253',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('254',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('255',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('256',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('257',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('258',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('259',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('260',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('261',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('262',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('263',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('264',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('265',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('266',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('267',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('268',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('269',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('270',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('271',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('272',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('273',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('274',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('275',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('276',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('277',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('278',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('279',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('280',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('281',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('282',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('283',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('284',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('285',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('286',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('287',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('288',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('289',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('290',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('291',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('292',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('293',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('294',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('295',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('296',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('297',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('298',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('299',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('300',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('301',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('302',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('303',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('304',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('305',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('306',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('307',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('308',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('309',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('310',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('311',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('312',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('313',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('314',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('315',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('316',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('317',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('318',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('319',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('320',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('321',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('322',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('323',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('324',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('325',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('326',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('327',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('328',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('329',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('330',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('331',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('332',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('333',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('334',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('335',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('336',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('337',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('338',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('339',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('340',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('341',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('342',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('343',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('344',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('345',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('346',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('347',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('348',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('349',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('350',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('351',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('352',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('353',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('354',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('355',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('356',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('357',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('358',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('359',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('360',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('361',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('362',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('363',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('364',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('365',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('366',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('367',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('368',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('369',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('370',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('371',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('372',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('373',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('374',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('375',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('376',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('377',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('378',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('379',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('380',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('381',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('382',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('383',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('384',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('385',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('386',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('387',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('388',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('389',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('390',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('391',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('392',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('393',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('394',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('395',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('396',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('397',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('398',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('399',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('400',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('401',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('402',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('403',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('404',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('405',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('406',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('407',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('408',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('409',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('410',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('411',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('412',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('413',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('414',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('415',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('416',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('417',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('418',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('419',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('420',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('421',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('422',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('423',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('424',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('425',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('426',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('427',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('428',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('429',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('430',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('431',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('432',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('433',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('434',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('435',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('436',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('437',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('438',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('439',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('440',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('441',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('442',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('443',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('444',NULL);
INSERT INTO `production_ID` (`production_ID`,`AMAS`) VALUES ('445',NULL);
/*!40000 ALTER TABLE `production_ID` ENABLE KEYS */;


--
-- Create Table `species`
--

DROP TABLE IF EXISTS `species`;
CREATE TABLE `species` (
  `scientific` varchar(45) NOT NULL,
  `common` varchar(45) NOT NULL,
  PRIMARY KEY (`common`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `species`
--

/*!40000 ALTER TABLE `species` DISABLE KEYS */;
INSERT INTO `species` (`scientific`,`common`) VALUES ('Tunnus alalunga','Albacore');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Sarda sarda','Atlantic bonito');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Brama brama','Atlantic pomfret');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Sphyraena sphyraena','Barracuda');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Alopias superciliosus','Bigeye thresher');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Spondyliosoma cantharus','Black seabream');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Euthynnus alleteratus','Black skipjack');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Centrolophus niger','Blackfish');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Dasyatis violacea','Blue stingray');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Prionace glauca','Blue-shark');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Auxis rochei','Bullet tuna');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Scomber japonicus','Chub mackerel');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Dasyatis pastinaca','Common stingray');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Calonectris diomedea','Cory\'s Shearwater');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Mobula mobular','Devil ray');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Epinephelus caninus','Dogtooth grouper');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Coryphaena hippurus','Dolphin-fish');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Epinephelus guaza','Dusky grouper');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Myliobatidae','Eagle or Bull ray');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Anguillidae','Eel');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Conger conger','European conger');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Merluccius merluccius','European hake');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Phycis spp','Forkbeard');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Auxis thazard','Frigate tuna');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Epinephelus alexandrinus','Golden grouper');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Schedophilus ovalis','Imperial blackfish');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Lichia amia','Leerfish');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Trachurus spp','Mackerels');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Muraena helena','Med. Morey');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Ommastrephes bartrami','Neon Flying Squid');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Ruvettus pretiosus','Oilfish');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Squalus acanthias','Piked dogfish');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Dasyatidae','Ray');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Trachipterus trachypterus','Ribbon fish');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Carcharhinus plumbeus','Sandbar shark');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Scorpaena spp','Scorpion/Rockfish');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Sea-turtle','Sea-turtle');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Seagull','Seagull');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Shark','Shark');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Isurus oxyrinchus','Shortfin mako');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Lepidopus caudatus','Silver scabbardfish');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Sphyraena zygaena','Smooth hummerhead');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Tetrapterus belone','Spearfish');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Squalidae','Squalus');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Cephalopods','Squid');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Dasyatidae','Stingrays');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Mola mola','Sunfish');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Xiphias gladius','Swordfish');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Alopias vulpinus','Thresher shark');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Galeorhinus galeus','Tope shark');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Carcharodon carcharias','White-shark');
INSERT INTO `species` (`scientific`,`common`) VALUES ('Polyprion americanus','Wreckfish');
/*!40000 ALTER TABLE `species` ENABLE KEYS */;


--
-- Create Table `species_measurements`
--

DROP TABLE IF EXISTS `species_measurements`;
CREATE TABLE `species_measurements` (
  `measure_expedition_ID` int(11) NOT NULL,
  `species` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `measure_ID` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`measure_ID`),
  UNIQUE KEY `measure_ID_UNIQUE` (`measure_ID`),
  KEY `expedition_ID_idx` (`measure_expedition_ID`),
  CONSTRAINT `measure_expedition_ID` FOREIGN KEY (`measure_expedition_ID`) REFERENCES `vessel_expeditions` (`expedition_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=greek;

--
-- Data for Table `species_measurements`
--

/*!40000 ALTER TABLE `species_measurements` DISABLE KEYS */;
/*!40000 ALTER TABLE `species_measurements` ENABLE KEYS */;


--
-- Create Table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `privileges` varchar(45) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_logout` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`username`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=greek;

--
-- Data for Table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`username`,`password`,`privileges`,`last_login`,`last_logout`) VALUES ('admin1','0','admin','2014-01-11 00:02:30','2013-12-24 10:02:59');
INSERT INTO `users` (`username`,`password`,`privileges`,`last_login`,`last_logout`) VALUES ('enaspanw','enaskatw','user','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `users` (`username`,`password`,`privileges`,`last_login`,`last_logout`) VALUES ('GeorgePatelis','123456','user','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `users` (`username`,`password`,`privileges`,`last_login`,`last_logout`) VALUES ('moderator1','0','moderator','2014-01-05 23:26:13','0000-00-00 00:00:00');
INSERT INTO `users` (`username`,`password`,`privileges`,`last_login`,`last_logout`) VALUES ('user1','0','user','2014-01-09 16:32:57','2013-12-20 22:31:47');
INSERT INTO `users` (`username`,`password`,`privileges`,`last_login`,`last_logout`) VALUES ('vagsmyrn','12345','user','0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;


--
-- Create Table `users_action_history`
--

DROP TABLE IF EXISTS `users_action_history`;
CREATE TABLE `users_action_history` (
  `action_ID` int(11) NOT NULL AUTO_INCREMENT,
  `action_username` varchar(45) DEFAULT NULL,
  `action_AMAS` varchar(45) DEFAULT NULL,
  `action_vproduction_ID` int(11) DEFAULT NULL,
  `action_pproduction_ID` int(11) DEFAULT NULL,
  `action_eexpedition_ID` int(11) DEFAULT NULL,
  `action_size_expedition_ID` int(11) DEFAULT NULL,
  `action_ALBmeasure` int(11) DEFAULT NULL,
  `action_BFTmeasure` int(11) DEFAULT NULL,
  `action_RVTmeasure` int(11) DEFAULT NULL,
  `action_SWOmeasure` int(11) DEFAULT NULL,
  `action_OTHERmeasure` int(11) DEFAULT NULL,
  `action_newuser` varchar(45) DEFAULT NULL,
  `action_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`action_ID`),
  KEY `username` (`action_username`),
  KEY `username_2` (`action_username`),
  KEY `username_3` (`action_username`),
  KEY `username_4` (`action_username`),
  KEY `action_AMAS` (`action_AMAS`,`action_vproduction_ID`,`action_pproduction_ID`,`action_eexpedition_ID`,`action_size_expedition_ID`,`action_ALBmeasure`,`action_BFTmeasure`,`action_RVTmeasure`,`action_SWOmeasure`,`action_OTHERmeasure`),
  KEY `action_production_ID` (`action_vproduction_ID`,`action_pproduction_ID`,`action_eexpedition_ID`,`action_size_expedition_ID`,`action_ALBmeasure`,`action_BFTmeasure`,`action_RVTmeasure`,`action_SWOmeasure`,`action_OTHERmeasure`),
  KEY `action_vproduction_ID` (`action_vproduction_ID`),
  KEY `action_pproduction_ID` (`action_pproduction_ID`),
  KEY `action_eexpedition_ID` (`action_eexpedition_ID`),
  KEY `action_size_expedition_ID` (`action_size_expedition_ID`),
  KEY `action_ALBmeasure` (`action_ALBmeasure`),
  KEY `action_BFTmeasure` (`action_BFTmeasure`),
  KEY `action_RVTmeasure` (`action_RVTmeasure`),
  KEY `action_SWOmeasure` (`action_SWOmeasure`),
  KEY `action_OTHERmeasure` (`action_OTHERmeasure`),
  CONSTRAINT `users_action_history_ibfk_1` FOREIGN KEY (`action_username`) REFERENCES `users` (`username`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `users_action_history_ibfk_10` FOREIGN KEY (`action_ALBmeasure`) REFERENCES `ALBmeasure` (`ALB_measure_ID`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `users_action_history_ibfk_11` FOREIGN KEY (`action_BFTmeasure`) REFERENCES `BFTmeasure` (`BFT_measure_ID`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `users_action_history_ibfk_12` FOREIGN KEY (`action_RVTmeasure`) REFERENCES `RVTmeasure` (`RVT_measure_ID`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `users_action_history_ibfk_13` FOREIGN KEY (`action_SWOmeasure`) REFERENCES `SWOmeasure` (`SWO_measure_ID`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `users_action_history_ibfk_14` FOREIGN KEY (`action_OTHERmeasure`) REFERENCES `OTHERmeasure` (`OTHER_measure_ID`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `users_action_history_ibfk_2` FOREIGN KEY (`action_AMAS`) REFERENCES `vessel` (`AMAS`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `users_action_history_ibfk_4` FOREIGN KEY (`action_vproduction_ID`) REFERENCES `dynamic_vessel` (`vessel_production_ID`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `users_action_history_ibfk_5` FOREIGN KEY (`action_pproduction_ID`) REFERENCES `production` (`production_ID`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `users_action_history_ibfk_8` FOREIGN KEY (`action_size_expedition_ID`) REFERENCES `expedition_size` (`size_expedition_ID`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=greek;

--
-- Data for Table `users_action_history`
--

/*!40000 ALTER TABLE `users_action_history` DISABLE KEYS */;
INSERT INTO `users_action_history` (`action_ID`,`action_username`,`action_AMAS`,`action_vproduction_ID`,`action_pproduction_ID`,`action_eexpedition_ID`,`action_size_expedition_ID`,`action_ALBmeasure`,`action_BFTmeasure`,`action_RVTmeasure`,`action_SWOmeasure`,`action_OTHERmeasure`,`action_newuser`,`action_date`) VALUES ('12','admin1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GeorgePatelis','0000-00-00 00:00:00');
INSERT INTO `users_action_history` (`action_ID`,`action_username`,`action_AMAS`,`action_vproduction_ID`,`action_pproduction_ID`,`action_eexpedition_ID`,`action_size_expedition_ID`,`action_ALBmeasure`,`action_BFTmeasure`,`action_RVTmeasure`,`action_SWOmeasure`,`action_OTHERmeasure`,`action_newuser`,`action_date`) VALUES ('13','admin1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'enaspanw','2014-01-11 00:47:27');
/*!40000 ALTER TABLE `users_action_history` ENABLE KEYS */;


--
-- Create Table `vessel`
--

DROP TABLE IF EXISTS `vessel`;
CREATE TABLE `vessel` (
  `AMAS` varchar(45) CHARACTER SET greek NOT NULL,
  `vessel_name` varchar(45) DEFAULT NULL,
  `reg_no_state` varchar(45) DEFAULT NULL,
  `port` varchar(45) DEFAULT NULL,
  `port_area` varchar(45) DEFAULT NULL,
  `grt` varchar(45) DEFAULT NULL,
  `vl` varchar(45) DEFAULT NULL,
  `vlc` varchar(45) DEFAULT NULL,
  `vw` varchar(45) DEFAULT NULL,
  `hp` varchar(45) DEFAULT NULL,
  `gears` varchar(45) NOT NULL,
  `navigation` varchar(100) DEFAULT NULL,
  `communication` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`AMAS`),
  UNIQUE KEY `AMAS_UNIQUE` (`AMAS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `vessel`
--

/*!40000 ALTER TABLE `vessel` DISABLE KEYS */;
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('1','Αγία Μαρίνα','440','HAN',NULL,'11,6099996567','11,8999996185','1','4','148','Ξ,Π,Δ,Κ','RD,PX,LR','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('10','Βιβάκος','Ν.Χ. 132','HAN',NULL,'28,0300006866','13,1999998093',NULL,'4,5999999046','150','Ξ,Π,Δ','RD,PX','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('1009','Σκεύος','Ν.Κ. 93','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('101','Ειρήνη','Ν.Χ. 196','HAN',NULL,NULL,'18','2',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('1016','Σπύρος','Ν.Κ. 276','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('1017','Σειρήνα','Ν.Κ. 96','OTH',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('1018','Αλκμήνη','Ν.Ρ. 413','OTH',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('1020','Φανούρης',NULL,'KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('1021','Ανάργυρος',NULL,'KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('1022','Happiness',NULL,'KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('1023','Φουρνιώτης',NULL,'KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('1024','Καπ. Κυριάκος',NULL,'KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('1045','Βασίλης','Ν.Κώ','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('105','Καπ. Μανώλης Ι',NULL,'HAN',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('1061','Καπ. Βασίλης',NULL,'KAL',NULL,NULL,NULL,'2',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('1062','Αγ. Νικόλαος','Ν.Κ. 160','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('1063','Παύλος',NULL,'KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('1065','Τσαμπίκα',NULL,'KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('107','Κώστας',NULL,'HAN',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('1070','ΘΥΕΛΛΑ',NULL,'OTH',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('1073','Hellenic Spirit',NULL,'OTH',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('11','Γεώργιος','Ν.Χ. 476','HAN',NULL,'8,8599996567','9,1000003815',NULL,'3,4000000954','48','Ξ,Π,Δ','PX','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('111','Σπυρίδων Σ',NULL,'HAN',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('113','Τα δύο αδέλφια','Ν.Χ. 196','HAN',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('119','Βασίλειος',NULL,'HAN',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('12','Γεώργιος Λ.','Ν.Χ. 137','HAN',NULL,'47,7000007629','17,7000007629',NULL,'5,2300000191','150','Ξ,Π,Δ,Κ','RD,PX,LR','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('125','Νικόλαος',NULL,'HAN',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('128','Αγ. Νικόλαος','Ν.Κ. 271','KAL',NULL,'8','11','1','3','60','Ξ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('129','Κων/νος','Ν.Κ. 62','KAL',NULL,'13','13','1','4','75','Ξ,Δ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('13','Γρηγόριος','Ν.Χ. 496','HAN',NULL,'19,6000003815','15,4499998093',NULL,'4,9800000191','150','Ξ,Δ,Π,ΣΥΡ','RD,PX','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('130','Παναγία Τήνου','Ν.Κ. 75','KAL',NULL,'19','13,6499996185','1','4,5','210','Ξ,Δ,Π','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('131','Τσάλης','Ν.Κ. 59','KAL',NULL,'21,0300006866','14,3000001907','1','4,5900001526','160','Ξ,Δ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('132','Αγ. Νικόλαος','Ν.Κ. 95','KAL',NULL,'22,3700008392','13','1',NULL,'220','','R',NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('133','Νιώτης','Ν.Κ. 101','KAL',NULL,'23,2099990845','14,3999996185','1','5','195','Ξ,Δ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('134','Πόπη','Ν.Κ. 99','KAL',NULL,'23,2099990845','14,3999996185','1','5','120','Ξ,Δ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('135','Μπέσσυ','Ν.Κ. 62','KAL',NULL,'26','15,3000001907','1','5','185','Ξ,Π','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('136','Αγ. Νικόλαος','Ν.Κ. 47','KAL',NULL,'26,3700008392','15,5','2','5','195','Ξ,Καταδ.','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('137','Πανορμίτης Κ.','Ν.Κ. 139','KAL',NULL,'28,7999992371','15,5','2','4,6799998283','220','Ξ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('138','Παναγία Καμαρίου','Ν.Κ. 64','KAL',NULL,'31,9699993134','17','2','5,6500000954','400','Ξ,Α','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('139','Καπ. Σκεύος','Ν.Κ. 92','KAL',NULL,'33,8600006104','15,6700000763','2','5','240','Ξ,Δ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('14','Δήμητρα','Ν.Χ. 386','HAN',NULL,'28,0499992371','13,8000001907',NULL,'4,5','148','Ξ,Π,Δ','RD,PX','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('140','Σακης-Θεοφίλης','Ν.Κ. 109','KAL',NULL,'39,9000015259','16','2','5,4000000954','220','Ξ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('141','Κάλυμνος','Ν.Κ. 112','KAL',NULL,'81','23,2199993134','3','7,5','420','Ξ,Π','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('142','Ιωάννα','Ν.Κ. 53','KAL',NULL,'25,2700004578','15','2','5,0999999046','177','Ξ,Π','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('143','Αγ. Γεώργιος Τελέντου','Ν.Κ. 469','KAL',NULL,NULL,NULL,'1',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('144','Αγγελική1',NULL,'KAL',NULL,NULL,NULL,'1',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('145','Αγ. Δημήτριος','Ν.Κ. 275','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'','Radar, GPS Plotter','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('146','Δύο αδέλφια','Ν.Κ. 186','KAL',NULL,NULL,NULL,'2',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('147','Καπ. Φουρτούνας','Ν.Κ. 103','KAL',NULL,NULL,NULL,'2',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('148','Μαρία Κ.',NULL,'KAL',NULL,NULL,'18','2',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('149','Νικόλαος','Ν.Κ. 392','KAL',NULL,NULL,NULL,'1',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('15','Εμμανουήλ','Ν.Χ. 413','HAN',NULL,'15,1199998856','12,6999998093',NULL,'4,25','122','Ξ,Π,Δ','RD,PX','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('150','Άγ. Πέτρος','Ν.Κ. 303','KAL',NULL,'10,6800003052','12','1',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('151','Αγ. Σπυρίδων','Ν.Κ. 374','KAL',NULL,'7,6999998093','10','1','3,6800000668','80','Ξ,Π','RD','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('152','Κωστάκης',NULL,'KAL',NULL,NULL,'10',NULL,NULL,NULL,'Δ,Π',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('153','Αγ. Νεκτάριος','Ν.Κ. 66','KAL',NULL,'24,0799999237','15',NULL,NULL,'235','Ξ,Π','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('154','Τρία Αδέλφια','Ν.Κ. 223','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'Ξ,Δ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('155','Ατζελα','Ν.Κ. 104','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'Ξ,Δ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('157','Αγ. Ειρήνη Χρυσοβαλάντου','Ν.Κ. 165','KAL',NULL,NULL,'12','1',NULL,'75','','R',NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('158','Ιωάννης Κ.','Ν.Κ. 88','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('159','Καπ. Μανώλης','Ν.Κ. 219','KAL',NULL,NULL,'13','1',NULL,NULL,'','Radar',NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('16','Ευάγγελος',NULL,'HAN',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('160','Αγ. Χαράλαμπος','Ν.Κ. 36','KAL',NULL,NULL,'13,5','1',NULL,'150','','R','SSB');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('162','Αγ. Γεώργιος','Ν.Κ. 164','KAL',NULL,'28','14,9499998093','2','5,1799998283','257','Ξ,Δ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('165','Αγ. Σάββας','N.K. 397','KAL',NULL,'20,3299999237','12','1','4,1999998093','120','Ξ,Δ,Π','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('167','Αναστασιος/Πανορμίτης','Ν.Κ. 172','KAL',NULL,'23','14,8999996185','1','5,8000001907','110','Ξ,Π','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('168','Γεωργούλης Γ.','Ν.Κ. 393','KAL',NULL,'11,3800001144','18,3500003815','2','5,6500000954','85','Ξ,Δ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('169','Καπετάν Γεωργούλης','Ν.Κ. 158','KAL',NULL,'27','15','2','6','102','Ξ,Δ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('17','Ιωάννης ΙΙ','Ν.Χ. 384','HAN',NULL,'6,1399998665','8,5500001907',NULL,'3,2400000095','115','Ξ,Π,Δ,Κ','RD,PX,LR','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('171','Δύο αδέλφια','Ν.Κ. 187','KAL',NULL,NULL,NULL,'2',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('172','Ιορδάνης II','Ν.Κ. 161','KAL',NULL,'30','15','2','5,4000000954','340','Ξ,Δ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('175','Καπ. Αγησίλαος','Ν.Κ. 188','KAL',NULL,'22,7999992371','14,9499998093','2','5,6199998856','110','Ξ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('177','Καπ. Αριστείδης','Ν.Κ. 162','KAL',NULL,'20','15','2','5,4000000954','120','Ξ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('18','Ιωάννης Σ','Ν.Χ. 180','HAN',NULL,'28,2399997711','17,1000003815',NULL,'5,3000001907','135','Ξ,Π,Δ','RD,PX','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('180','Κωστάκης','Ν.Κ. 338','KAL',NULL,NULL,'10',NULL,NULL,NULL,'Δ,Π',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('181','Μαρία Ζ.','Ν.Κ. 186','KAL',NULL,'20,8299999237','16,7199993134','2','5,3499999046','150','Ξ,Δ,Π','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('184','Νικόλαος-Aννούλα','Ν.Κ. 90','KAL',NULL,NULL,'17','2',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('185','Νικόλαος-Ειρήνη','Ν.Κ. 443','KAL',NULL,'11,0200004578','17,3999996185','2','5,5999999046','165','Ξ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('186','Νίκος','N.K. 452','KAL',NULL,'14,5','12,5','1','4','114','Ξ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('19','Κατερίνα','Ν.Χ. 103','HAN',NULL,'13,1400003433','11,8000001907',NULL,'3,9000000954','135','Ξ,Π,Δ','RD,PX,LR','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('194','Σεβαστος ΙΙ','Ν.Κ. 160','KAL',NULL,'27,25','15,25','2','5,25','145','Ξ,Π','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('196','Ταξιάρχης','Ν.Κ. 190','KAL',NULL,'16','14','1',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('2','Αγία Πελαγία','122','HAN',NULL,'33,7999992371','13,1999998093',NULL,'4,5999999046','175','Ξ,Π,Δ,Κ','RD,PX,LR','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('20','Κυρά της Ρώ','Ν.Χ. 376','HAN',NULL,'10,1300001144','10,5',NULL,'3,7000000477','80','Ξ,Π,Δ','PX','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('21','Κώστας Κ','Ν.Χ. 447','HAN',NULL,'27,8600006104','13,9499998093',NULL,'4,5','150','Ξ,Π,Δ','RD','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('22','Μύρων Π','Ν.Χ.113','HAN',NULL,'44,5900001526','17,2000007629',NULL,'5,1399998665','150','Ξ,Π,Δ','RD,PX,LR','VHF,SSB');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('23','Νίκος Ο','Ν.Χ. 432','HAN',NULL,'11,8500003815','11,6999998093',NULL,'4,3000001907','145','Ξ,Π,Δ,Κ','RD','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('236','Αγ. Γεώργιος','Ν.Κ. 194','KAL',NULL,'25','18','2',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('238','Αγ. Νικόλαος','Ν.Κ. 510','KAL',NULL,'10,5100002289','14,8500003815','1','5,3000001907','84','Ξ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('24','Παναγιώτα','Ν.Χ. 429','HAN',NULL,'17,9400005341','12,6000003815',NULL,'4,3000001907','80','Ξ,Π,Δ,Κ','RD,PX','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('25','Τα δύο αδέλφια','Ν.Χ. 147','HAN',NULL,'26,9599990845','13,5',NULL,'4,5999999046','150','Ξ,Π,Δ,Κ','RD,PX','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('254','Κώστας Μ.','Ν.Κ. 479','KAL',NULL,'16,5900001526','14,1000003815','1','4,4000000954','180','Ξ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('258','Νικος','N.K. 452','KAL',NULL,'14,5','12,5','1','4','114','Ξ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('26','Τολμηρός ΙΙ','Ν.Χ. 118','HAN',NULL,'59','18,6000003815',NULL,'5,5999999046','150','Ξ,Π,Δ,Κ','RD,PX,LR,AP','VHF,SSB');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('261','Παναγία Τήνου','N.K. 75','KAL',NULL,'19','13,6499996185','1','4,5','210','Ξ,Δ,Π','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('27','Φουντουλάκης','Ν.Χ. 183','HAN',NULL,'26,6800003052','19,2999992371',NULL,'5,3000001907','150','Ξ,Π,Δ,Κ','RD,PX','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('271','Britl','Ν.Κ. 164','KAL',NULL,'28','14,9499998093','1','5,1799998283','257','Ξ,Δ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('274','Αγ. Παντελεήμονας',NULL,'KAL',NULL,'27','18','2',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('276','Αγγελική',NULL,'KAL',NULL,'11','17','2',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('28','Χρήστος ΙΙ','Ν.Χ. 405','HAN',NULL,'25,8899993896','13,1999998093',NULL,'4,5999999046','150','Ξ,Π,Δ,Κ','RD,PX,LR','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('280','Δημήτριος',NULL,'KAL',NULL,NULL,'14','1',NULL,NULL,'Ξ,Δ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('282','Ιορδάνης II','161','KAL',NULL,'30','15','2','5,4000000954','340','Ξ,Δ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('289','Μαρία Ζ.',NULL,'KAL',NULL,'20,8299999237','16,7199993134','2','5,3499999046','150','Ξ,Δ,Π','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('29','Χριστίνα','Ν.Χ. 331','HAN',NULL,'2,3900001049','7,0999999046',NULL,'2,5','12','Ξ,Π,Δ',NULL,'VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('290','Νικόλαος','392','KAL',NULL,NULL,'14','1',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('295','Παναγία Τελέντου','N.K. 292','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('296','Πανορμίτης',NULL,'KAL',NULL,NULL,'13',NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('297','Πέτρος',NULL,'KAL',NULL,NULL,'12','1',NULL,NULL,'Δ, Π',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('299','Σακελλάρης','Ν.Κ. 422','KAL',NULL,'20','15','2',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('3','Αλμπατρος','475','HAN',NULL,'4,9699997902','8,9499998093',NULL,NULL,'15','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('30','Αγία Μαρίνα','Ν.Χ. 440','HAN',NULL,'11,6099996567','11,8999996185',NULL,'4','148','Ξ,Π,Δ,Κ','RD,PX,LR','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('301','Σοφία','Ν.Κ. 198','KAL',NULL,'25','16',NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('307','Αγ. Κων/νος','Ν.Ρ. 562','KAL',NULL,'15,5','12','1',NULL,'75','Ξ, Δ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('31','Αγία Πελαγία','Ν.Χ. 122','HAN',NULL,'33,7999992371','13,1999998093',NULL,'4,5999999046','175','Ξ,Π,Δ,Κ','RD,PX,LR','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('313','Αρχων Μιχαήλ','N.K. 524','KAL',NULL,'11,3800001144','18,2000007629','2','5,3000001907','122','Ξ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('32','Αλμπατρος','Ν.Χ. 475','HAN',NULL,'4,9699997902','8,9499998093',NULL,NULL,'15','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('321','Καπ. Ευθύμης','Ν.Κ. 239','KAL',NULL,'15,8599996567','13,6000003815','2',NULL,'140','Ξ,Δ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('328','Νικολέττα','Ν.Κ. 75','KAL',NULL,'19','13,6499996185','2','4,5','210','Ξ,Δ,Π','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('33','Ανδρέας Σ','Ν.Χ. 431','HAN',NULL,'10,5500001907','12,5',NULL,'3,4000000954','135','Ξ,Π,Δ,Κ','RD','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('332','Πανορμίτης Σύμης',NULL,'KAL',NULL,'12','12','1',NULL,'75','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('339','Στέφανος','Ν.Κ. 49','KAL',NULL,'14','12','1',NULL,'75','Ξ,Δ-Π',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('34','Αντώνιος','Ν.Χ. 133','HAN',NULL,'33,7999992371','13,1999998093',NULL,'4,5999999046','238','Ξ,Π,Δ,Κ','RD,PX,LR','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('346','Γεωργούλης Γ.','N.K. 393','KAL',NULL,'11,3800001144','18,3500003815','2','5,6500000954','85','Ξ,Δ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('347','Καπ. Αγησίλαος','N.K. 188','KAL',NULL,'22,7999992371','14,9499998093','2','5,6199998856','110','Ξ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('349','Καπ. Αριστείδης','N.K. 162','KAL',NULL,'20','15','2','5,4000000954','120','Ξ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('35','Ατρόμητος','Ν.Χ. 126','HAN',NULL,'38,2999992371','14,9499998093',NULL,'4,6999998093','150','Ξ,Π,Δ,Κ','RD,PX','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('353','Νικολέττα','N.K. 75','KAL',NULL,'19','13,6499996185','2','4,5','210','Ξ,Δ,Π','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('355','Πόπη','N.K. 99','KAL',NULL,'23,2099990845','14,3999996185','2','5','120','Ξ,Δ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('356','Σακελλάρης','N.K. 422','KAL',NULL,'20','15','2',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('357','Σεβαστος II','N.K. 160','KAL',NULL,'27,25','15,25','2','5,25','145','Ξ,Π,Αστακ.','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('358','Σοφία','N.K. 198','KAL',NULL,'25','16','2',NULL,NULL,'Ξ-Δ-Π',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('359','Τσάλης','N.K. 59','KAL',NULL,'21,0300006866','14,3000001907','2','4,5900001526','160','Ξ,Τ, κυρτος για γαρι','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('36','Αχιλλέας','Ν.Χ. 430','HAN',NULL,'17,9400005341','12,6000003815',NULL,'4,3000001907','150','Ξ,Π,Δ,Κ','RD,PX,LR','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('360','Αρχων Μιχαήλ','Σ.Κ. 20','KAL',NULL,'4,1999998093','9,9200000763','1','3','40','Ξ,...','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('362','Αγ. Κων/νος','526','KAL',NULL,'15,5','12','1',NULL,'75','Ξ, Δ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('364','Ταξιάρχης','N.K. 190','KAL',NULL,'16','14','1',NULL,NULL,'Δ,Π',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('366','Αναστασιος/Πανορμίτης','N.K. 172','KAL',NULL,'23','14,8999996185','1','5,8000001907','110','Ξ,Π','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('374','Αγ. Δημήτριος','N.K. 530','KAL',NULL,NULL,'18','2',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('375','Αγγελής Κ.','N.K. 525','KAL',NULL,NULL,'15','2',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('376','Britl','164','KAL',NULL,'28','14,9499998093','2','5,1799998283','257','Ξ,Δ','RD,GPS','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('381','Στέφανος','49','KAL',NULL,'14','12','1',NULL,'75','Ξ,Δ-Π',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('382','Δήμητρα','Ν.Ι. 183','HAL',NULL,'5,1199998856','9,3000001907',NULL,'3,5999999046','22,0499992371','Ξ, ΑΛ, Δ,Π,Καθ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('383','Αφρούλα','Ν.Ι. 194','HAL',NULL,'5,1100001335','9,1999998093',NULL,'3,5999999046','11,029999733','LLC, LAL, BLL, HL, N',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('384','Μαρία','Ν.Ι. 142','HAL',NULL,'20,3500003815','14,8800001144',NULL,'5,4899997711','44,1100006104','Ξ, ΑΛ, Π,Καθ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('385','Αντώνιος','Ν.Ι. 279','HAL',NULL,'3,3299999237','8,1999998093',NULL,'3,2000000477','11,0200004578','Ξ, ΑΛ, Π,Καθ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('386','Δημήτρης','Ν.Ι. 193','HAL',NULL,'5,6900000572','9,3000001907',NULL,'3,7999999523','23,5200004578','Ξ, ΑΛ, Δ,Π,Καθ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('387','Γρηγορούσα','Ν.Ι. 161','HAL',NULL,'3,8299999237','9,1999998093',NULL,'3,7400000095','11,029999733','Ξ, Καθ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('388','Σμαραγδή','Ν.Ι. 228','HAL',NULL,'8,9399995804','11,8500003815','1','4,0599999428','52,9199981689','LLC, LAL, BLL, HL, N',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('389','Παναγία','Ν.Ι. 113','HAL',NULL,NULL,'9,1999998093',NULL,'3','63','Ξ, ΑΛ, Δ,Π,Καθ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('390','Νικολάκης','Ν.Ι. 172','HAL',NULL,NULL,'8,5',NULL,'3,0999999046','11,0200004578','Ξ, ΑΛ, Δ,Π,Καθ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('391','Ελπίδα','Ν.Θ. 1598','HAL',NULL,'10','12,25','1','4','37,4900016785','LLC, LAL, BLL, HL, N',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('392','Καπετάν Παναής','Ν.Ι. 170','HAL',NULL,'5,3800001144','9,1000003815',NULL,'3,7999999523','32,3400001526','Ξ, ΑΛ, Δ,Π',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('393','Διαλεχτή','Ν.Θ. 1596','HAL',NULL,'14,9200000763','13,3999996185','1','4,75','106,5800018311','LLC, LAL, BLL, HL',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('394','Εφη','Ν.Ι. 282','HAL',NULL,'22,6700000763','13,6999998093','1','5,0999999046','73,5100021362','LLC, LAL, BLL, HL',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('395','Αγ. Νικόλαος','Ν.Ι. 92','HAL',NULL,'10,9200000763','12,1000003815',NULL,'4,25','69,8300018311','Ξ, ΑΛ, Δ,Π,Καθ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('396','Γαλήνη','Ν.Θ. 1630','HAL',NULL,'11,470000267','11,470000267',NULL,'4,3299999237','89,6800003052','Ξ, ΑΛ, Δ,Π,Καθ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('397','Απόστολος','Ν.Ι.191','HAL',NULL,'6,0399999619','9,5',NULL,'3,6500000954','11,029999733','Ξ, ΑΛ, Δ,Π,Καθ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('398','Αγ. Νικόλαος','Ν.Σ. 13','HAL',NULL,'20,25','14,1300001144',NULL,'4,6700000763','110,2600021362','LAL, BLL, LLC,',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('399','Αγ. Γεώργιος','Ν.Θ. 910','HAL',NULL,'11,8299999237','12,3500003815','1','4,4600000381','121,2900009155','LAL, LLC, BLL, HL',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('4','Ανδρέας Σ','431','HAN',NULL,'10,5500001907','12,5',NULL,'3,4000000954','135','Ξ,Π,Δ,Κ','RD','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('400','Ευάγγελος','Ν.Ι. 64','HAL',NULL,'19,6700000763','14',NULL,'5','110,2699966431','Ξ, ΑΛ, Π,Καθ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('401','Παναγία Κανάλα','Ν.Θ. 1236','HAL',NULL,'15,7899999619','13,5',NULL,'4,6999998093','110,2600021362','Ξ, ΑΛ, Π,Καθ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('402','Αγ. Ραφαήλ','Ν.Μ. 11','HAL',NULL,'10,9399995804','12,6999998093','1','4,8600001335','150,6999969482','LAL',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('403','Καπ. Δημήτρης','Ν.Μ. 340','HAL',NULL,'4,3099999428','8,6000003815',NULL,'3,0999999046','44,0999984741','ΑΛ, Π,Καθ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('404','Αθανάσιος Λ.','Ν.Θ. 1593','HAL',NULL,'15,3599996567','13,6000003815','1','4,5','91,9100036621','LAL, LLC, HL, BLL',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('405','Αγ. Γεώργιος','Ν.Ι. 159','HAL',NULL,'4,2600002289','9',NULL,'3,7999999523','11,029999733','Ξ, ΑΛ, Π,Καθ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('406','Δημήτρης','Ν.Θ. 996','HAL',NULL,'16,2000007629','13,8000001907',NULL,'4,5','147,0200042725','LLC, LAL, BLL, HL',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('407','Στέλιος-Γιάννης','Λ.Μ. 335','HAL',NULL,'3,5199999809','8,6000003815','1','3,4000000954','11,029999733','LAL,BLL, HL',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('408','Θοδωρής','Λ.Ν.Μ. 1876','HAL',NULL,'2,8299999237','7,8699998856','1','2,9000000954','62,8300018311','LLC, LAL, HL, BLL',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('409','Αγ. Ειρήνη','Ν.Κ. 1066','KAL',NULL,NULL,'11,8000001907','1',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('410','Καπ. Κωσταντής','Ν.Κ. 519','KAL',NULL,'16,7000007629','11,8000001907','1',NULL,'110','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('413','Γιάννης Κ.','Ν.Κ. 78','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('414','Άτζελα','Ν.Κ. 104','KAL',NULL,NULL,'17,3999996185','2',NULL,'220','','Son, Lor, R, AP','SSB');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('415','Παν. Καμαρίου','Ν.Κ. 64','KAL',NULL,NULL,'17','2',NULL,'400','','Lor, R','SSB');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('417','Καπετάν Αναστάσης','Ν.Κ. 93','KAL',NULL,NULL,'15,6999998093','2',NULL,'240','','R',NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('418','Αναστάσιος Κ.','Ν.Κ. 77','KAL',NULL,NULL,'15,4499998093','2',NULL,'300','','R',NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('420','Γεωργούλης Σ.','Ν.Κ. 98','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('421','Γεωργούλης Β.','Ν.Κ. 91','KAL',NULL,NULL,'17,8999996185','2',NULL,'286','','R, AP','SSB');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('422','Χρυσοπηγή','Ν.Κ. 72','KAL',NULL,NULL,'15','2',NULL,'140','','R','SSB');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('423','Παναγής Κόρος','Ν.Κ. 53','KAL',NULL,NULL,'15','2',NULL,'178','','R','SSB');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('426','Κύκνος','Ν.Λ. 135','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('427','Ειρήνη 2',NULL,'KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('428','2 Αδέλφια','Ν.Κ. 222','KAL',NULL,NULL,'11,6999998093','1',NULL,'150','','R',NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('429','Σάκης-Θεοφίλης','Ν.Κ. 109','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'','R, AP, Sat',NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('433','Νίκη Ι',NULL,'KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('434','Καπετάν Γιάννης','Ν.Κ. 215','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('436','Ειρήνη','Ν.Κ. 224','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('437','8 Αδέλφια','Ν.Κ. 51','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('439','Βιβάκος 1','Ν.Χ. 139','HAN',NULL,NULL,'13,1999998093','1',NULL,'150','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('440','Νίκος','Ν.Χ. 409','HAN',NULL,NULL,'13,1999998093','1',NULL,'150','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('441','Αγ. Φανούριος','Ν.Χ. 121','HAN',NULL,NULL,'13','1',NULL,'130','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('444','Κυριάκος Π.','Ν.Χ. 127','HAN',NULL,NULL,'24,5799999237','3',NULL,'225','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('446','Ειρήνη ΙΙ','Ν.Χ. 149','CYC',NULL,'38,1800003052','14,9499998093','1',NULL,'150','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('447','Νικολίνα','Ν.Σ. 997','CYC',NULL,'12,6059999466','12,5500001907','1',NULL,'95','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('448','Καπ. Διονύσης','Ν.Σ. 901','CYC',NULL,'24','14,8000001907','1',NULL,'140','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('449','Αγ. Μαρίνα','Ν.Π. 3743','CYC',NULL,'32','15','2',NULL,'120','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('45','Θαραλλέος',NULL,'HAN',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('450','Νίκη 2','Ν.Η. 58','CYC',NULL,'16,2199993134','13','1',NULL,'135','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('451','Μαρία1','Ν.Σ. 944','CYC',NULL,'23,2600002289','13,1999998093','1',NULL,'150','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('452','Αντώνης 2','Ν.Μ.','CYC',NULL,'21,6599998474','13,5','1',NULL,'150','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('453','Περδίκης','Ν.Η. 55','CRE',NULL,'10,8000001907','13','1',NULL,'150','','R, Son',NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('454','Λιάκος','Ν.ΠΑ.','OTH',NULL,NULL,'11,3000001907','1',NULL,'50','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('455','Χρήστος','Ν.ΠΑ. 332','OTH',NULL,NULL,'16,8500003815','2',NULL,'185185','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('456','Χριστίνα','Ν.ΠΑ. 645','OTH',NULL,NULL,'13','1',NULL,'175','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('457','Παναγία','Ν.ΠΑ. 296','OTH',NULL,NULL,'18,4400005341','2',NULL,'360','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('458','Αθηνά','Ν.ΚΑΤ. 03','OTH',NULL,NULL,'9',NULL,NULL,'5050','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('459','Αγ. Νικόλαος','Ν.ΚΑΛΑΜ. 473','OTH',NULL,NULL,'10,3000001907','1',NULL,'36','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('460','Ζαρατούστρα','Ν.ΠΥΛ. 13','OTH',NULL,NULL,'16','2',NULL,'125150','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('461','Βασίλης Σ.','Ν.ΚΑΛΑΜ. 552','OTH',NULL,NULL,'12','1',NULL,'120','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('462','Έλλη-Φωνή','Ν.ΚΑΛΑΜ. 995','OTH',NULL,NULL,'8',NULL,NULL,'72','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('463','Ταξιάρχης','Ν.ΚΑΛΑΜ. 556','OTH',NULL,NULL,'14','1',NULL,'150','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('464','Κούλα Μ.','Ν.ΚΑΛΑΜ. 577','OTH',NULL,NULL,'15','2',NULL,'150','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('465','Αγ. Νικόλαος','Ν.ΚΑΛΑΜ. 489','OTH',NULL,NULL,'9,5',NULL,NULL,'60','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('466','Χριστίνα','Ν.ΚΑΛΑΜ. 539','OTH',NULL,NULL,'13,1000003815','1',NULL,'100','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('467','Στέλιος','Ν.ΚΑΛΑΜ. 569','OTH',NULL,NULL,'10,6000003815','1',NULL,'120','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('468','Φώτιος','Ν.ΚΑΛΑΜ. 482','OTH',NULL,NULL,'10,0399999619','1',NULL,'130','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('469','Δημήτριος','Ν.ΓΥΘ. 25','OTH',NULL,NULL,'8,1999998093',NULL,NULL,'46','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('470','Γεώργιος','Ν.ΓΥΘ. 28','OTH',NULL,NULL,'12,5','1',NULL,'140','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('471','Γεώργιος','Ν.ΓΥΘ. 27','OTH',NULL,NULL,'8',NULL,NULL,'46','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('472','Χαράλαμπος Α.','Ν.ΝΕΑΠ. 2','OTH',NULL,NULL,'10,8199996948','1',NULL,'90','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('473','Θεόδωρος','Ν.ΝΕΑΠ. 7','OTH',NULL,NULL,'13','1',NULL,'115','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('474','Παναγιώτης','Ν.Υ. 930','OTH',NULL,NULL,'9,1999998093',NULL,NULL,'75','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('475','Ποσειδών','Ν.Υ. 964','OTH',NULL,NULL,'9,5',NULL,NULL,'75','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('476','Ταξιάρχης','Ν.Υ. 979','OTH',NULL,NULL,'10','1',NULL,'75','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('477','Αγ. Φωτεινή','Ν.Υ. 943','OTH',NULL,NULL,'10,1000003815','1',NULL,'75','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('478','Κυραργυρώ','Ν.ΣΠ. 284','OTH',NULL,NULL,'14,1999998093','1',NULL,'240','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('479','Ξιφίας','Ν.ΣΠ. 267','OTH',NULL,NULL,'14,5','1',NULL,'170','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('480','Ζεύς 2','Ν.ΣΠ. 1207','OTH',NULL,NULL,'9,1999998093',NULL,NULL,'60','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('481','Δημήτριος','Ν.ΣΠ. 1208','OTH',NULL,NULL,'9,5',NULL,NULL,'55','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('482','Ιωάννης','Ν.ΓΥΘ. 9','OTH',NULL,NULL,'13,5','1',NULL,'135','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('483','Νικόλαος','Ν.ΣΠ. 1259','OTH',NULL,NULL,'11,5','1',NULL,'75','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('484','Χαράλαμπος','Ν.ΣΠ. 1181','OTH',NULL,NULL,'12,5','1',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('485','Καπ. Κοσμάς','Ν.ΚΑΛΑΜ. 387','OTH',NULL,NULL,'10,5','1',NULL,'75','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('486','Καπ. Μιχάλης','Ν.ΚΑΛΑΜ. 477','OTH',NULL,NULL,'12,8000001907','1',NULL,'110','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('487','Παναγής','Ν.Π.ΧΕΛΙ 2','OTH',NULL,NULL,'13,5','1',NULL,'120','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('488','Τασία','Ν.ΝΕΑΠ. 11','OTH',NULL,NULL,'10,0500001907','1',NULL,'200','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('489','Κοσμάς Ρ.','Ν.ΝΕΑΠ. 693','OTH',NULL,NULL,'8,3000001907',NULL,NULL,'33','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('490','Καπ. Βασιλάκης','Ν.ΠΕΙΡ. 4194','OTH',NULL,NULL,'12','1',NULL,'120','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('491','Καπ. Κοσμάς','Ν.ΚΑΛΑΜ. 476','OTH',NULL,NULL,'12,5','1',NULL,'120','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('492','Καπ. Κοσμάς','Ν.ΠΕΙΡ. 2075','OTH',NULL,NULL,'13','1',NULL,'160','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('493','Καπ. Παναγιώτης','Ν.ΓΥΘ. 11','OTH',NULL,NULL,'12,5','1',NULL,'75','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('494','Παναγία','Ν. ΛΑΥΡ. 378','OTH',NULL,NULL,'13,3000001907','1',NULL,'180','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('495','Ναυτίλος','Ν.ΠΕΙΡ. 1888','OTH',NULL,NULL,'14','1',NULL,'6060','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('496','Μαριάνθη','Ν.Π. 4736','OTH',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('497','Διαμαντής',NULL,'OTH',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('498','Ζούρντος',NULL,'OTH',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('499','Αργυρώ-Πόπη','Ν.ΒΟΛ. 1333','OTH',NULL,NULL,'10,5','1',NULL,'130','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('5','Αντώνιος','133','HAN',NULL,'33,7999992371','13,1999998093',NULL,'4,5999999046','238','Ξ,Π,Δ,Κ','RD,PX,LR','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('500','Άφοβος','Ν.ΙΕΡ. 35','OTH',NULL,NULL,'17','2',NULL,'320','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('501','Ελευθέριος Κ.','Ν.Β. 504','OTH',NULL,NULL,'16','2',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('502','Γιαννάκης','Ν.Β. 537','OTH',NULL,NULL,'16','2',NULL,'240','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('503','Κώστας','Ν.ΙΕΡ. 36','OTH',NULL,NULL,'16','2',NULL,'420','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('504','Αργυρώ','Ν.Β. 598','OTH',NULL,NULL,'14,5','1',NULL,'160','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('505','Ατρόμητος','Ν.Β. 1068','OTH',NULL,NULL,'14,1999998093','1',NULL,'100','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('506','Χιλή','Ν.ΚΥΜ. 171','OTH',NULL,NULL,'18','2',NULL,'320','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('507','Αγ. Παντελεήμονας','Ν.Β.586','OTH',NULL,NULL,'14','1',NULL,'110','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('508','Μανούλι','Ν.Β. 596','OTH',NULL,NULL,'17','2',NULL,'296','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('509','Σταθάκης','Ν.Β.1445','OTH',NULL,NULL,'9,6000003815',NULL,NULL,'84','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('51','Μύρων Π','Ν.Χ. 113','HAN',NULL,'44,5900001526','17,2000007629',NULL,'5,1399998665','150','Ξ,Π,Δ','RD,PX,LR','VHF,SSB');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('510','Κων/νος Δ.','Ν.Β.569','OTH',NULL,NULL,'16,75','2',NULL,'240','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('511','Κων/νος Γ.','Ν.Β. 585','OTH',NULL,NULL,'17,5','2',NULL,'160','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('512','Φουντουλάκης','183','HAN',NULL,'26,6800003052','19,2999992371','2',NULL,'150','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('516','Αγ. Νεκτάριος',NULL,'HAN',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('52','Νίκη',NULL,'HAN',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('530','Κώστας Μ.','Ν.Κ. 523','KAL',NULL,'16,5900001526','14,1000003815','2',NULL,'180','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('549','Αγ. Νικόλαος','Ν.Κ. 21','ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('550','Χριστίνα',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('551','Αγ. Νικόλαος','Ν.Π. 79','ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('552','Γλάρος',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('553','Άννα',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('554','Σπουργιτάκι 3',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('555','Αγ. Ραφαήλ',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('556','Ωκεανής',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('557','Ελπίδα',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('558','Αλέξανδρος',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('559','Ειρήνη',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('560','Χριστάκης',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('561','Γεώργιος',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('562','Γεράσιμος',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('563','Ταξιάρχης-Γεώργιος',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('564','Ιωάννης Μ.',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('565','Ξιφίας',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('566','Όστρια',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('567','Αγ. Γεώργιος',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('568','Ωκεανός',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('569','Παναγιώτης',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('570','Ευσταθία',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('571','Κωνσταντίνος',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('572','Ελένη',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('574','Μιχάλης','30075/239','ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('575','Αγ. Ανάργυροι','593/548','ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('576','Αγ. Νικόλαος','29745/450',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('586','Στέφανος Χ.',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('587','Ευαγγελίστρια',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('588','Αγ. Νικόλαος',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('589','Χρήστος',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('590','Τασία',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('591','Κανάλα',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('592','Θεοσκέπαστη',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('593','Νότα',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('594','Θηραμνία',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('595','Νίκος',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('596','Αγ. Ανάργυροι',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('598','Τσιπούρας',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('6','Ατρόμητος','126','HAN',NULL,'38,2999992371','14,9499998093',NULL,'4,6999998093','150','Ξ,Π,Δ,Κ','RD,PX','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('60','Αγ. Αννα','Ν.Χ. 550','HAN',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('600','Παν. Κανάλα 1',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('601','Παν. Κανάλα 2',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('605','Χαρίλαος',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('607','Μαρία',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('608','Αγ. Αικατερίνη',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('610','Ελπίς',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('613','Θηραμνία 2','Ν.Σ. 946','CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('619','Παν. Κανάλα (Αλέκος)',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('620','Παν. Κανάλα (Χρήστος Ηλιού)',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('624','Στέφανος',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('625','Κανάλα (Αλέκος)',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('626','Αγ. Αρσένιος',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('627','Παλαιολόγος',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('628','Χριστίνα 1',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('629','Καπ. Διονύσης',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('630','Αντώνιος ΙΙ',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('632','Λίμπερτυ ΙΙ',NULL,'CYC',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('633','Καπ. Γιάννης','Ν.Η. 274','CRE',NULL,'20','14','1',NULL,NULL,'Δ,Π',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('634','Κων/νος','Ν.Η. 233','CRE',NULL,'4,5','11,6000003815','1',NULL,'125','Δ,ΠΨ(αγκ11αρι),ΞΠ','GPS, Sonar','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('635','Αρμενιστής ΙΙ','Ν.Χ. 577','CRE',NULL,'10,8900003433','12,5','1',NULL,'130','Π, Δ, ΞΠ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('640','Καπ. Κώστας',NULL,'HAN',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('642','Αγ. Τριάς',NULL,'HAN',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('643','Θαλασσόλυκοι','Ν.Η. 29','CRE',NULL,'16,1599998474','12','1',NULL,'74','Ππατωτο, Δίχτυ','GPS, RADAR','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('645','Καλυψώ','Ν.Β. 1431','OTH',NULL,'11,6800003052','12,3999996185','1',NULL,'70,5699996948','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('646','Αφροδίτη','Ν.Σ. 108','OTH',NULL,'10,4899997711','10,6000003815','1',NULL,'36,7599983215','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ,ΠΑΓ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('647','Άγιος Δημήτριος','Λ.Α. 50','OTH',NULL,'3,6400001049','9',NULL,NULL,'36,0200004578','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('648','Άγιος Νικόλαος','Λ.Α. 116','OTH',NULL,'6,1599998474','10,220000267','1',NULL,'61,75','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('649','Καπετάν Σπύρος','Ν.Β. 658','OTH',NULL,'12,279999733','12,3000001907','1',NULL,'93,3600006104','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('650','Άγιος Νικόλαος','Λ.Α. 80','OTH',NULL,'5,9699997902','10,220000267','1',NULL,'41,1599998474','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('651','Άγιος Δημήτριος-Μαρία','Ν.Β. 1420','OTH',NULL,'10,75','11,5','1',NULL,'94,0899963379','ΞΠ,ΤΠ,ΠΒ,ΣΔ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('652','Αλόνησος','Λ.Β. 1650','OTH',NULL,'6,2300000191','10,5','1',NULL,'95,5599975586','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('653','Άγιος Νικόλαος','Ν.Σ. 74','OTH',NULL,'10,6300001144','11,1999998093','1',NULL,'84,5400009155','ΞΠ,ΤΠ,ΠΒ,ΣΔ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('654','Λένα','Λ.Α. 163','OTH',NULL,'1,2300000191','6,1999998093',NULL,NULL,'11,029999733','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('655','Θύελλα','Ν.Β. 1393','OTH',NULL,'7,2899999619','11,1000003815','1',NULL,'80,8600006104','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('656','Κων/νος-Ελένη','Λ.Β. 6381','OTH',NULL,'4,4299998283','9',NULL,NULL,'36,7599983215','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('657','Άγιος Νικόλαος','Λ.Α. 93','OTH',NULL,'1,9800000191','7,6999998093',NULL,NULL,'7,3499999046','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('658','Άγιος Νικόλαος','Λ.Α. 66','OTH',NULL,'5,8600001335','10','1',NULL,'53,6599998474','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('659','Άγιος Ηλίας','Ν.Α. 934','OTH',NULL,'9,3199996948','10,8999996185','1',NULL,'61','ΞΠ,ΤΠ,ΠΒ,ΣΔ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('660','Ταξιάρχης','Λ.Α. 176','OTH',NULL,'2,0999999046','7,5999999046',NULL,NULL,'22,0499992371','ΞΠ,ΤΠ,ΠΒ,ΣΔ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('661','Αγαλού-Σμαραγδή','Ν.Β. 1379','OTH',NULL,'7,5900001526','10,8999996185','1',NULL,'38,2299995422','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ,ΠΑΓ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('662','Ευαγγελίστρια','Ν.Β. 1389','OTH',NULL,'7,0799999237','10,3000001907','1',NULL,'41,1699981689','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('663','Άγιος Νικόλαος','Λ.Α. 137','OTH',NULL,'3,8900001049','8,6000003815',NULL,NULL,'38','ΞΠ,ΤΠ,ΠΒ,ΣΔ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('664','Κων/νος','Λ.Α. 25','OTH',NULL,'1,7799999714','7,3000001907',NULL,NULL,'5,8800001144','ΞΠ,ΤΠ,ΠΒ,ΣΔ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('665','Άγιος Δημήτριος','Λ.Σ. 234','OTH',NULL,'2,5599999428','8,1000003815',NULL,NULL,'39,7000007629','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ,ΠΑΓ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('666','Άγιος Δημήτριος','Λ.Α. 21','OTH',NULL,'1,5700000525','7,0999999046',NULL,NULL,'26,4599990845','ΞΠ,ΤΠ,ΠΒ,ΣΔ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('667','Άγιος Νικόλαος','Ν.Β. 1438','OTH',NULL,'2,8900001049','8',NULL,NULL,'88,2099990845','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ,ΠΑΓ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('668','Παναγία ΙΙ','Ν.Β. 1565','OTH',NULL,'4,5100002289','8,6000003815',NULL,NULL,'27,5900001526','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('669','Καπετάν Τάκης','Ν.Α. 63','ALO',NULL,'4,0100002289','8,5',NULL,NULL,'22,0499992371','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('670','Στυλιανός','Ν.Σ. 71','OTH',NULL,'3,0799999237','8,6000003815',NULL,NULL,'22,0499992371','ΞΠ,ΤΠ,ΠΒ,ΣΔ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('671','Θαλασσοπόρος','Ν.Β. 1574','OTH',NULL,'22','15,8999996185',NULL,NULL,'69,9800033569','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ,ΠΑΓ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('672','Μαχούλα','Ν.Σ. 96','OTH',NULL,'3,7300000191','8,8999996185',NULL,NULL,'11,029999733','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('673','Ράνια','Ν.Β. 1619','OTH',NULL,'6,4299998283','9,8000001907',NULL,NULL,'24,2600002289','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ,ΠΑΓ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('674','Γιάννης','Ν.Β. 1627','OTH',NULL,'4,3699998856','9,1999998093',NULL,NULL,'33,8100013733','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ,ΠΑΓ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('675','Άγιος Γεώργιος','Ν.Σ. 118','OTH',NULL,'5,6900000572','10,3999996185',NULL,NULL,'36,75','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('676','Ταξιάρχης','Ν.Σ. 124','OTH',NULL,'3,7000000477','8,6999998093',NULL,NULL,'36,7599983215','ΞΠ,ΤΠ,ΠΒ,ΣΔ,ΠΑΓ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('677','Αυγερινός','Λ.Σ. 726','OTH',NULL,'4,2699999809','8,6999998093',NULL,NULL,'11,029999733','ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ,ΠΑΓ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('678','Άγιος Δημήτριος','Ν.Σ. 43','OTH',NULL,NULL,NULL,NULL,NULL,NULL,'ΞΠ,ΤΠ,ΠΒ,ΣΔ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('679','Δημήτριος','Ν.ΣΘ. 1001','OTH',NULL,NULL,NULL,NULL,NULL,NULL,'ΞΠ,ΤΠ,ΠΒ,ΣΔ,ΠΑΓ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('680','Λένια','Ν.Α. 387','OTH',NULL,NULL,NULL,NULL,NULL,NULL,'ΞΠ,ΤΠ,ΠΒ,ΣΔ,Κ,ΠΑΓ',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('681','Φουντουλάκης','N.X. 183','HAN',NULL,'52','19,2999992371','2','5,3000001907','150','ΞΠ,Σ,ΔΜπ,ΠΒ','2GPS,AΠ,R,Son,Ραδιογ','SSB,2VHF,Navtex,Sart');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('682','Δημήτριος Κ.','Ν.Π. 7397','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('7','Αχιλλέας','430','HAN',NULL,'17,9400005341','12,6000003815',NULL,'4,3000001907','150','Ξ,Π,Δ,Κ','RD,PX,LR','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('702','ανώνυμος',NULL,'HAN',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('721','Ζαφείρης-Κατερίνα','Ν.Ι. 279','HAL',NULL,'3,3299999237','8,1999998093','1','3,2000000477','11,0200004578','LLC, LAL, BLL, HL',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('742','Λίντα 1',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('743','Αθηνά',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('744','Δελφίνι',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('745','Καπετάν Μιχάλης',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('746','Αρχάγγελλος',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('747','Γιάννης',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('748','Λίντα 2',NULL,'ION',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('749','Καπ. Νικόλας',NULL,'KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('758','Βασίλειος','Ν.Χ. 496','HAN',NULL,'22','15,4499998093','2','4,6999998093','150','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('764','Πόπη','N.K. 226','KAL',NULL,'23,2099990845','14,3999996185','1',NULL,'120','',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('769','Απόστολος Κ.','Ν.Κ. 212','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('774','Κωστάκης','Ν.ΧΑΛ. 1219','KAL',NULL,'9,3000001907','13,5','1','4,1999998093','30','BLL, N,','GPS Plotter, Radar, Sonar','VHF, Ψυγείο');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('790','Νικόλαος','Ν.Μ. 26','HAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('8','Βαλέρια','Ν.Χ. 425','HAN',NULL,'25,0100002289','18,1499996185',NULL,'4,7199997902','220','Ξ,Π,Δ,ΓΡ','RD,PX','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('805','Κωνσταντίνος-Ελένη','Σ.Α. 34','ALO',NULL,NULL,NULL,NULL,NULL,NULL,'LAL, BLL, N, HL',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('806','Σταμάτης','Ν.Σ. 124','ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('807','Ευαγγελίστρια','Λ.Α. 139','ALO',NULL,NULL,NULL,NULL,NULL,NULL,'BLL, N, HL',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('808','Γρηγοράκης Τέλης',NULL,'ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('810','Καπετάν Γιακουμής','Ν.Θ. 1447','HAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('811','Μαλαματή','Ν.Θ. 1076','HAL',NULL,NULL,'9,1999998093','1',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('812','Παναγιώτης','Ν.Μ. 1094','HAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('813','Τασούλα','Ν.Θ. 1035','HAL',NULL,NULL,'11,6499996185','1',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('814','Άγ. Δημήτριος ΙΙ','Ν.Θ. 959','HAL',NULL,NULL,'9,3000001907','1',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('815','Διαμαντάκης ΑΚ','Ν.Λ. 9','HAL',NULL,NULL,'14,8999996185','1',NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('836','Κωνσταντίνος-Μαρία','Ν.Κ. 560','KAL',NULL,'26','16,2999992371','2',NULL,'115','N, BLL, LLA',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('855','Κατερίνα','Ν.Χ. 190','CRE',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('876','Αντώνιος','Ν.Χ. 617','HAN',NULL,NULL,'11,2299995422','1',NULL,'48,125','LLC, N, BLL','Radar, Plotter','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('879','Καπετάν Στράτος','Ν.Χ. 606','HAN',NULL,NULL,'10,6999998093','1',NULL,'100,5899963379','LLC',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('883','ΘΑΛΑΣΣΟΜΑΧΟΣ',NULL,'CYC',NULL,NULL,'6',NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('897','V1',NULL,'ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('898','V2',NULL,'ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('899','V3',NULL,'ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('9','Βασιλική','Ν.Χ. 124','HAN',NULL,'33,7999992371','13,1999998093',NULL,'4,5999999046','144','Ξ,Π,Δ,Κ','RD,PX','VHF');
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('900','V4',NULL,'ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('901','V5',NULL,'ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('902','V6',NULL,'ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('903','V7',NULL,'ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('904','V8',NULL,'ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('905','V9',NULL,'ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('906','V10',NULL,'ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('907','V11',NULL,'ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('908','V12',NULL,'ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('909','V13',NULL,'ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('910','V14',NULL,'ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('911','V15',NULL,'ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('912','V16',NULL,'ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('913','V17',NULL,'ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('914','V18',NULL,'ALO',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('917','Ανάσταση','Ν.Κ. 593','KAL',NULL,'18,8400001526','14','1','4,1999998093','70','LLA, TRP',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('93','Αντώνιος','Ν.Χ. 134','HAN',NULL,NULL,NULL,NULL,'0',NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('930','Απόστολος Κ.','Ν.Ι. 106','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('932','Ζωρντός','Ν.ΑΙΓ. 67','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('933','Αγ. Νικόλαος','Ν.Κ. 340','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('934','Αγ. Γεράσιμος','Ν.Κ. 60','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('938','Καπ. Τάσος','Ν.Κ. 90','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('939','Nikolaos Theodosios',NULL,'KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('941','Κώστας','Ν.Κ. 63','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('942','Nikolaos San Lorentso',NULL,'KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('945','Καπ. Νικόλαος','Ν.Κ. 448','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('948','Γεωργούλης Κ.','Ν.Κ. 55','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('955','Δύο αδέλφια','Ν.Κ. 82','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('957','Πόπη','Ν.Κ. 8','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('959','Αγ. Νικόλαος','Ν.Κ. 165','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('965','Καπετάν Μιχάλης','Ν.Κ. 49','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('966','Αγ. Κυριακή','Ν.Κ. 98','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('971','Π. Μιχαλάκης','Ν.Κ. 176','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('973','Πάτερ Σάββας','Ν.Κ. 24','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('974','Καπετάν Δημήτρης','Ν.Κ. 269','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('977','Αγ. Νικόλαος','Ν.Κ. 76','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('978','Νικ. Σδρέγας','Ν.Κ. 26','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('979','Νίκη','Ν.Κ. 42','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('980','Καπετάν Νικήτας','Ν.Κ. 37','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('981','Πανορμίτης','Ν.Κ. 13','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
INSERT INTO `vessel` (`AMAS`,`vessel_name`,`reg_no_state`,`port`,`port_area`,`grt`,`vl`,`vlc`,`vw`,`hp`,`gears`,`navigation`,`communication`) VALUES ('982','Δέσποινα','Ν.Κ. 41','KAL',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL);
/*!40000 ALTER TABLE `vessel` ENABLE KEYS */;


--
-- Create Table `vessel_expeditions`
--

DROP TABLE IF EXISTS `vessel_expeditions`;
CREATE TABLE `vessel_expeditions` (
  `vexpedition_AMAS` varchar(45) CHARACTER SET greek DEFAULT NULL,
  `expedition_ID` int(11) NOT NULL,
  PRIMARY KEY (`expedition_ID`),
  UNIQUE KEY `expedition_ID_UNIQUE` (`expedition_ID`),
  KEY `AMAS_idx` (`vexpedition_AMAS`),
  CONSTRAINT `vexpedition_AMAS` FOREIGN KEY (`vexpedition_AMAS`) REFERENCES `vessel` (`AMAS`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `v_exp_id` FOREIGN KEY (`expedition_ID`) REFERENCES `expedition` (`expedition_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `vessel_expeditions`
--

/*!40000 ALTER TABLE `vessel_expeditions` DISABLE KEYS */;
/*!40000 ALTER TABLE `vessel_expeditions` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

